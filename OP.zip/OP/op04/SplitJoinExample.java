package op04;
/**
 * Example how to use split and join for string.
 * 
 * @author Henning Dierks
 * @version 1.0
 */

public class SplitJoinExample {
  /**
   * Splits a string and joins the parts again.
   * @param args not used here 
   */
  public static void main(String[] args) {
    String text = 
        "Das ist-ein Text, der verschiedene?"
            + "Symbole enthält!Aha.Ist ja spannend.";

    // Split with " " as separator
    String[] parts = text.split(" ");

    for (int i = 0; i < parts.length; i++) {
      System.out.println(" Teil " + i 
                         + " : >" + parts[i] + "<");
    }

    // Split with severals symbols as separator
    parts = text.split("[- ,?!.]"); 

    for (int i = 0; i < parts.length; i++) {
      System.out.println(" Teil " + i 
                         + " : >" + parts[i] + "<");
    }
    // and now join them with ":"
    String j = String.join(":",parts); 
    System.out.println(j);
  }
}
