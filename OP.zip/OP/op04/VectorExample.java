package op04;
import java.util.Vector;

/**
 * Simple class to demonstrate the use of vectors.
 * 
 * <p>Adaption of class VectorTest1 from D. Abts
 * @author Henning Dierks
 * @version 1.0
 */

public class VectorExample {
  /**
   * Constructs a vector of customers and prints them.
   * @param args not used here
   */
  public static void main(String[] args) {
    // Customer-Vector
    Vector<Customer> customers = new Vector<Customer>(); 

    customers.add(new Customer("C3PO", "Stiftstraße 69"));
    customers.add(new Customer("BB8", "Berliner Tor 5"));
    customers.add(0, 
                  new Customer("R2D2", "Berliner Tor 7"));

    for (int i = 0; i < customers.size(); i++) {
      Customer c = customers.get(i); // No cast necessary
      System.out.println(c.getName() + ", " 
                        + c.getAddress());
    }

    System.out.println();
    for (Customer c : customers) { // alternative syntax
      System.out.println(c.getName() + ", " 
                         + c.getAddress());
    }
  }
}


