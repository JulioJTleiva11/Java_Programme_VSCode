package op04;
/**
 * Simple class to execute string comparisons.
 * 
 * <p>Adaption of class Vergleiche from D. Abts
 * @author Henning Dierks
 * @version 1.0
 */

public class StringComparisonExample {
  /**
   * Creates three strings with same content. 
   * @param args not used here
   */
  public static void main(String[] args) {
    String a = "Hallo";  
    String b = new String(a);  // new address!
    String c = "Hallo"; // same address as a 

    System.out.println(a.equals(b)); 
    // true, because contents are equal
    System.out.println(a == b); 
    // false, because addresses differ
    System.out.println(a == c); 
    // true, because addresses are equal
  }
}
