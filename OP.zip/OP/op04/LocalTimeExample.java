package op04;

import java.time.LocalTime;
import java.time.temporal.ChronoUnit;

/**
 * Example how to use LocalTime.
 * 
 * @author Henning Dierks
 * @version 1.0
 */
public class LocalTimeExample {

  public static void main(String[] args) {
    LocalTime now          = LocalTime.now();
    LocalTime endOfLecture = LocalTime.parse("15:25");
    if ( now.isBefore(endOfLecture) ) {
      System.out.println("Noch "
        + now.until( endOfLecture, ChronoUnit.MINUTES )
        + " Minuten bis Feierabend");
    } 
  }
}
