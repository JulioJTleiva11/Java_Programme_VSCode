package op04;

import java.util.Enumeration;
import java.util.Hashtable;

/**
 * Simple class to demonstrate the use of hash tables.
 * 
 * @author Henning Dierks
 * @version 1.0
 */

class Kanzler {
  public static void main(String[] args) {
    // creates hash table first
    Hashtable<String,Integer[]> kanzler
      = new Hashtable<String,Integer[]>();

    kanzler.put(new String("Adenauer"),  
                new Integer[] {1949,1963});  
    kanzler.put(new String("Erhard"),    
                new Integer[] {1963,1966});
    kanzler.put(new String("Kiesinger"), 
                new Integer[] {1966,1969});
    kanzler.put(new String("Brandt"),    
                new Integer[] {1969,1974});
    kanzler.put(new String("Schmidt"),   
                new Integer[] {1974,1982});
    kanzler.put(new String("Kohl"),      
                new Integer[] {1982,1998});
    kanzler.put(new String("Schröder"),  
                new Integer[] {1998,2005});
    kanzler.put(new String("Merkel"),    
                new Integer[] {2005,2021});
    kanzler.put(new String("Scholz"), 
                new Integer[] {2021,2024});

    for (String arg : args) {         // all arguments
      if (kanzler.containsKey(arg)) { // if found
        Integer[] years = kanzler.get(arg);
          System.out.println("Kanzler(in) " + arg
                             + " von " + years[0]
                             + " bis " + years[1]);
      } else {
        System.out.println(arg + " war nie Kanzler(in)");
      }
    }
    // Printing the whole table. Watch the
    // order of the elements!
    Enumeration<String> e = kanzler.keys();
    while (e.hasMoreElements()) {
      String name =  e.nextElement();
      System.out.println("Kanzler(in) " + name);
    }
  }
}
