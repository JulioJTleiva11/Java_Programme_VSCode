package op02;

/**
 * Extended Rectangle, a 2d geometric object.
 * 
 * @author Henning Dierks
 * @version 1.0
 */

public class RectangleExtended 
    implements GeoExtended {
  
  private double width;
  private double height;

  public RectangleExtended(
      double width, 
      double height) {
    this.width = width;
    this.height = height;
  }

  @Override
  public double getHeight() {
    return height;
  }

  @Override
  public double getWidth() {
    return width;
  }
}
