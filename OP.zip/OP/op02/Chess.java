package op02;

/**
 * Example for a non-abstract subclass of Game.java.
 * 
 * @author Henning Dierks
 * @version 1.0
 */

public class Chess extends Game {

  @Override
  public Board startGame() {
    // TODO Auto-generated method stub
    return null;
  }

  @Override
  public void makeMove(Board b) {
    // TODO Auto-generated method stub
  }

  @Override
  public Boolean isFinished(Board b) {
    // TODO Auto-generated method stub
    return null;
  }

  @Override
  public void declareResult(Board b) {
    // TODO Auto-generated method stub
  }   

  /* kann man ueberschreiben, wenn noetig:
  @Override 
  public void play() { ... }
   */
}
