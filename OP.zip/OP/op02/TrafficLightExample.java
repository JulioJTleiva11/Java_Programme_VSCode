package op02;

/**
 * Example how to use enums.
 * 
 * <p>Adaption of class Test from D. Abts
 * @author Henning Dierks
 * @version 1.0
 */

public class TrafficLightExample {
  /**
   * prints out some information about the color. 
   * @param color the color of interest
   */
  public static void info(TrafficLightColor color) {
	// ordinal returns the number 
	System.out.print(color.ordinal());
    switch (color) {
      case RED: // works in cases!
        System.out.println(": Anhalten");
        break;
      case YELLOW: 
        System.out.println(": Achtung");
        break;
      case GREEN:
        System.out.println(": Weiterfahren");
        break;
      default: 
        System.out.println(": Unbekannte Farbe");
    }
  }

  /**
   * Plays around with the enum features. 
   * @param args not used here
   */
  public static void main(String[] args) {
    info(TrafficLightColor.RED);
    info(TrafficLightColor.YELLOW);
    info(TrafficLightColor.GREEN);

    // TrafficLightColor.values returns all values  
    for (TrafficLightColor 
    		color : TrafficLightColor.values()) {
      // color.toString() returns the name of the element 
      System.out.println(color.toString());
    }
  }
}
