package op02.constructors;
/**
 * Simple Account with several constructors
 * 
 * <p>Adaption of class KontoTest from D. Abts
 * @author Henning Dierks
 * @version 1.0
 */

public class Account {
  // Attributes
  private int accountnumber;  // number of account
  private double balance;     // how much money 

  // constructors

  // default constructor must be programmed explicitly 
  // as we have other constructors  
  public Account() { } 

  public Account(int accountnumber) { // no balance given
    this.accountnumber = accountnumber;
    this.balance = 0.0; // not necessary, 0.0 is default
  }

  public Account(int accountnumber, double balance) {
    this.accountnumber = accountnumber;
    this.balance = balance;
  }

  public Account(Account anOther) { // copy constructor
    this.accountnumber = anOther.accountnumber; // copy 
    this.balance       = anOther.balance;       // copy
  }

  // Getters and Setters
  public int getAccountnumber() {
    return accountnumber;
  }

  public void setAccountnumber(int newNumber) {
    accountnumber = newNumber;
  }

  public double getBalance() {
    return balance;
  }

  public void setBalance(double newBalance) {
    balance = newBalance;
  }

  // Methods
  /**
   * Increase balance of the account.
   * @param amount How much money is paid in 
   */
  public void payIn(double amount) { 
    balance += amount;
  }

  /**
   * Decrease balance of the account.
   * @param amount How much money is paid out
   */
  public void payOut(double amount) {
    balance -= amount;
  }

  public void info() {
    System.out.println("Account number: " + accountnumber 
        + " Balance: " + balance);
  }
}
