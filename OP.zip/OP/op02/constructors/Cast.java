package op02.constructors;

/**
 * Class to show up- and downcasting.
 * 
 * <p>Adaption of class Cast from D. Abts
 * @author Henning Dierks
 * @version 1.0
 */
public class Cast {
  /**
   * Creates an account (in fact a Giroaccount) and 
   * applies methods to demonstrate the effects of
   * casting.
   * @param args not used here
   */
  public static void main(String[] args) {
    // Upcast
    Account acc = new Giroaccount(1020, 800., 2000.);
    acc.payOut(3000.);
    System.out.println(acc.getBalance());

    // Downcast
    ((Giroaccount) acc).setLimit(2500.);
    acc.payOut(3000.);
    System.out.println(acc.getBalance());
  }
}
