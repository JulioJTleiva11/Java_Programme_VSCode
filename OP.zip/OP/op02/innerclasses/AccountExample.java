package op02.innerclasses;
/**
 * Example how to use class Account.
 * 
 * <p>Adaption of class KontoTest from D. Abts
 * @author Henning Dierks
 * @version 1.0 
 */

public class AccountExample {
  /**
   * Creates an account and uses transactions.
   * @param args not used here
   */  
  public static void main(String[] args) {
    Account acc = new Account(4711, 1000.);

    acc.payIn(500.);
    acc.payOut(700.);

    Account.Transaction t = acc.getLast();
    System.out.println(t.toString());
  }
}
