package op02.innerclasses;

public class A {
  int x;
  
  public Object m() {
    final int y = 42;
    int z=0;
    
    class B {
      int a = x*y;
      void mb() {
        a += x*y+z;
      
       }
      
    }
    
    return new B();
  }
}
