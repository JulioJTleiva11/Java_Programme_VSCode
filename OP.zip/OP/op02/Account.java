package op02;

/**
 * Simple Account.
 * 
 * <p>Adaption of class KontoTest from D. Abts
 * @author Henning Dierks
 * @version 1.1
 */

public class Account {
  // Attributes
  private int accountnumber;  // number of account
  private double balance;     // how much money 

  // Getters and Setters
  public int getAccountnumber() {
    return accountnumber;
  }

  public void setAccountnumber(int newNumber) {
    accountnumber = newNumber;
  }

  public double getBalance() {
    return balance;
  }

  public void setBalance(double newBalance) {
    balance = newBalance;
  }

  // Methods
  /**
   * Increase balance of the account.
   * @param amount How much money is paid in 
   */
  public void payIn(double amount) { 
    balance += amount;
  }

  /**
   * Decrease balance of the account.
   * @param amount How much money is paid out
   */
  public void payOut(double amount) {
    balance -= amount;
  }

  public void info() {
    System.out.println("Account number: " + accountnumber 
        + " Balance: " + balance);
  }
}
