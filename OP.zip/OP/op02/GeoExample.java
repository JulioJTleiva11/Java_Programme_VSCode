package op02;

/**
 * Example how to use interface Geo.
 * 
 * <p>Adaption of class GeoTest from D. Abts
 * @author Henning Dierks
 * @version 1.0 
 */

public class GeoExample {
  /**
   * Creates two Geo objects and computes their area.
   * @param args not used here
   */
  public static void main(String[] args) {
    Geo rec = new Rectangle(10.5, 4.799); 
    Geo cir = new Circle(4.0049);

    System.out.println(rec.getArea());
    System.out.println(cir.getArea());
  }
}
