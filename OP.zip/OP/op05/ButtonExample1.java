package op05;
import java.awt.Color;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;

/**
 * Example how to add a button to a window and how to react to it.
 * 
 * <p>Adaption of class ButtonTest1 from D. Abts
 * @author Henning Dierks
 * @version 1.0
 */
public class ButtonExample1 extends JFrame 
    implements ActionListener { // to get information 
  private Container contPane;
  private JButton button;
  private Random random = new Random(); // change background
  
  /**
   * Creates a window with a single button. 
   */
  public ButtonExample1() {
    super("Button");
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    contPane = getContentPane();
    contPane.setLayout(new FlowLayout());  // being lazy

    Icon icon = // we want a button with an icon!
        new ImageIcon(getClass().getResource("cat.gif"));
    button = new JButton("Bitte klicken", icon);
    button.setToolTipText("Test");  // it is so simple!
    button.addActionListener(this); // subscribe to button
    contPane.add(button);

    setSize(300, 200);
    setVisible(true);
  }


  /* (non-Javadoc)
   * @see java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
   */
  public void actionPerformed(ActionEvent e) {
    if (e.getSource() == button) {  // button pressed?
      contPane.setBackground(       // color randomly
          new Color(random.nextInt(256), 
              random.nextInt(256),
              random.nextInt(256)));
    } 
  }

  public static void main(String[] args) {
    new ButtonExample1();
  }
}
