package op01;

/**
 * Second JAVA program: Simple Window. 
 * @author Henning Dierks
 * @version 1.1
 */

import java.awt.Color;
import java.awt.Font;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;

@SuppressWarnings("serial")
public class Demo2 extends JFrame {
  /**
   * Generates a simple window.
   */
  public Demo2() {                 // Constructor 
    super("Ein erstes Fenster-Beispiel");  
    Icon icon =                    // we want an icon
        new ImageIcon(getClass().getResource("duke.gif"));
    JLabel label =                 // we want a text
        new JLabel("Viel Erfolg bei der Java-Vorlesung", 
            icon, JLabel.CENTER);  // put text in center
    add(label);                    // add it to window

    // define a font now
    Font font = new Font("SansSerif", Font.BOLD, 80);
    label.setFont(font);           // use this font now
    label.setForeground(Color.RED);// set some colors
    label.setBackground(Color.WHITE); 
    label.setOpaque(true);

    // meaning of X button  
    setDefaultCloseOperation(EXIT_ON_CLOSE); 
    setSize(1000, 800);    // initial size of window
    setLocation(10,10);    // initial position
    setVisible(true);      // show-time!
  }

  /**
   * Starts a single window.
   * @param args not used
   */
  public static void main(String[] args) {
    new Demo2();  // create a window-object
  }
} // end of class definition


