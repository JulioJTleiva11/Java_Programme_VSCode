package op07;
import java.io.File;
import java.io.IOException;
import java.util.Date;

/**
 * File information retriever.
 * 
 * <p>Adaption of class FileInfo from D. Abts
 * @author Henning Dierks
 * @version 1.0
 */
public class FileInfo {
  /**
   * Applies all useful methods to a file. 
   * @param args first argument is the file to analyse.
   */
  public static void main(String[] args) {
    File file = new File(args[0]);
    System.out.println("Name: " + file.getName());
    System.out.println("Path: " + file.getPath());
    System.out.println("AbsolutePath: " 
                       + file.getAbsolutePath());
    try {
      System.out.println("CanonicalPath: " 
                         + file.getCanonicalPath());
    } catch (IOException e) { // IO errors may occur
      e.printStackTrace();
    }
    System.out.println("Parent: " + file.getParent());
    System.out.println("exists: " + file.exists());
    System.out.println("canRead: " + file.canRead());
    System.out.println("canWrite: " + file.canWrite());
    System.out.println("isFile: " + file.isFile());
    System.out.println("isDirectory: " 
                       + file.isDirectory());
    System.out.println("isAbsolute: " 
                       + file.isAbsolute());
    System.out.println("length: " + file.length());
    System.out.println("lastModified: " 
                       + new Date(file.lastModified()));
  }
}
