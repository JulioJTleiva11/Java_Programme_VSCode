package op07;

public class ComplexConstants {
  private static final int MAX = 20;
  private static final 
    String fileName = "ComplexArray.dat";

  public static int getMax() {
    return MAX;
  }
  public static String getFilename() {
    return fileName;
  }
}
