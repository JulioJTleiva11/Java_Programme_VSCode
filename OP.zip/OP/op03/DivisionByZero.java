package op03;

/**
 * Example of a runtime exception.
 * 
 * <p>Adaption of class Division from D. Abts
 * @author Henning Dierks
 * @version 1.1
 */

public class DivisionByZero {
  /**
   * Produces an division by zero exception.
   * @param args not used here
   */
  public static void main(String[] args) {
    for (int i = 5; i >= 0; i--) {
      System.out.println("10:"+i+"=" + 
                         10 / i); // bad thing
    }
  }    
}
